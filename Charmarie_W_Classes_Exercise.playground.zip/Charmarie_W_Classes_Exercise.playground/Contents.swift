import UIKit

class jeepWrangler {
    var engine: String = "v8"
    var color: String = "grey"
    var upholstery: Bool = true
    
    func carDefined (){
        print("My car is grey")
    }
}
var car = jeepWrangler()
